import React, { useState, useCallback } from 'react';
import BottomNav from './components/BottomNav';
import HeroSection from './components/HeroSection';
import FeatureCards from './components/FeatureCards';
import LoginPanel from './components/LoginPanel';
import RegisterPanel from './components/RegisterPanel';

import Footer from './components/Footer';

type ModalType = 'login' | 'register' | null;

const App: React.FC = () => {
  const [modal, setModal] = useState<ModalType>(null);
  const [activeSection, setActiveSection] = useState('Home');

  const openRegister = useCallback(() => setModal('register'), []);
  const closeModal = useCallback(() => setModal(null), []);

  const handleNavClick = useCallback((section: string) => {
    setActiveSection(section);
    // Scroll to relevant section if it exists on the page
    const id = section.toLowerCase();
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, []);

  return (
    <div className="min-h-screen pb-24" style={{ background: '#080B2A' }}>
      {/* Navigation */}
      <BottomNav
        activeSection={activeSection}
        onNavClick={handleNavClick}
      />

      {/* Main Content */}
      <main>
        {/* Hero */}
        <HeroSection
          onGetStarted={openRegister}
          onWatchDemo={() => {}}
        />

        {/* Feature Cards */}
        <FeatureCards onGetStarted={openRegister} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals (portaled via conditional rendering) */}
      {modal === 'login' && (
        <LoginPanel
          onClose={closeModal}
          onSwitchToRegister={() => setModal('register')}
        />
      )}
      {modal === 'register' && (
        <RegisterPanel
          onClose={closeModal}
          onSwitchToLogin={() => setModal('login')}
        />
      )}
    </div>
  );
};

export default App;
