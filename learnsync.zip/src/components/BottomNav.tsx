import React from 'react';
import { Home, Compass, Users, Brain, MessageSquare, User } from 'lucide-react';

interface BottomNavProps {
  activeSection: string;
  onNavClick: (section: string) => void;
}

const NAV_ITEMS = [
  { name: 'Home', icon: Home },
  { name: 'Explore', icon: Compass },
  { name: 'Community', icon: Users },
  { name: 'Skills', icon: Brain },
  { name: 'Messages', icon: MessageSquare },
  { name: 'Profile', icon: User },
];

const BottomNav: React.FC<BottomNavProps> = ({ activeSection, onNavClick }) => {
  return (
    <nav className="fixed inset-x-0 bottom-0 mx-auto w-[calc(100%-2rem)] max-w-lg bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl shadow-xl flex justify-between items-center px-3 py-2" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 0.75rem)' }}>
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = activeSection === item.name;
        return (
          <button
            key={item.name}
            onClick={() => onNavClick(item.name)}
            className="flex flex-col items-center text-xs focus:outline-none"
            aria-label={item.name}
          >
            <Icon
              size={20}
              className={isActive ? 'text-primary' : 'text-white/60'}
            />
            <span className={isActive ? 'text-primary mt-0.5' : 'text-white/60 mt-0.5'}>{item.name}</span>
          </button>
        );
      })}
    </nav>
  );
};

export default BottomNav;
