import React, { useRef, useEffect } from 'react';
import { ArrowRight, Play } from 'lucide-react';
import HeroIllustration from './HeroIllustration';

interface HeroSectionProps {
  onGetStarted: () => void;
  onWatchDemo: () => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onGetStarted, onWatchDemo }) => {
  const badgeRef = useRef<HTMLDivElement>(null);
  const h1Ref = useRef<HTMLHeadingElement>(null);
  const subRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const els = [badgeRef.current, h1Ref.current, subRef.current, ctaRef.current];
    els.forEach((el, i) => {
      if (!el) return;
      el.style.opacity = '0';
      el.style.transform = 'translateY(28px)';
      setTimeout(() => {
        if (!el) return;
        el.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      }, 150 + i * 150);
    });
  }, []);

  return (
    <section
      id="hero"
      className="hero-bg grid-lines relative min-h-screen flex items-center pt-16"
      aria-label="Hero section"
    >
      {/* Background city silhouette */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <svg
          viewBox="0 0 1440 300"
          xmlns="http://www.w3.org/2000/svg"
          className="absolute bottom-0 left-0 right-0 w-full opacity-[0.07]"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          <path
            d="M0,300 L0,180 L80,180 L80,120 L120,120 L120,80 L160,80 L160,120 L200,120
               L200,100 L240,100 L240,60 L280,60 L280,100 L320,100 L320,140 L360,140
               L360,80 L400,80 L400,50 L440,50 L440,80 L480,80 L480,140 L520,140
               L520,100 L560,100 L560,70 L600,70 L600,110 L640,110 L640,160 L680,160
               L680,90 L720,90 L720,55 L760,55 L760,90 L800,90 L800,130 L840,130
               L840,80 L880,80 L880,110 L920,110 L920,70 L960,70 L960,110 L1000,110
               L1000,140 L1040,140 L1040,90 L1080,90 L1080,130 L1120,130 L1120,100
               L1160,100 L1160,140 L1200,140 L1200,180 L1280,180 L1280,160 L1360,160
               L1360,180 L1440,180 L1440,300 Z"
            fill="#A78BFA"
          />
        </svg>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-20 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Content */}
          <div className="flex flex-col gap-7">
            {/* Badge */}
            <div ref={badgeRef} className="inline-flex items-center gap-2 glass rounded-full px-4 py-2 w-fit">
              <span className="text-sm" aria-hidden="true">🚀</span>
              <span className="text-sm font-medium text-white/80">Learn • Share • Grow Together</span>
            </div>

            {/* Heading */}
            <h1 ref={h1Ref} className="text-5xl sm:text-6xl lg:text-5xl xl:text-6xl font-extrabold leading-[1.08] tracking-tight">
              <span className="text-white">Learn </span>
              <span className="text-gradient-purple">Together</span>
              <span className="text-white">. </span>
              <br />
              <span className="text-white">Share </span>
              <span className="text-gradient-purple">Skills</span>
              <span className="text-white">. </span>
              <br />
              <span className="text-white">Grow </span>
              <span className="text-gradient-purple">Together</span>
              <span className="text-white">.</span>
            </h1>

            {/* Subtitle */}
            <p ref={subRef} className="text-lg text-white/65 leading-relaxed max-w-lg">
              A premium student network where you can learn new skills, teach what you know,
              and connect with peers across colleges.
            </p>

            {/* CTA Buttons */}
            <div ref={ctaRef} className="flex flex-wrap gap-4">
              <button
                onClick={onGetStarted}
                className="btn-primary text-base px-7 py-3.5"
                aria-label="Get started with LearnSync"
              >
                Get Started
                <ArrowRight size={18} aria-hidden="true" />
              </button>

              <button
                onClick={onWatchDemo}
                className="btn-secondary text-base px-7 py-3.5"
                aria-label="Watch a demo of LearnSync"
              >
                <span className="w-8 h-8 rounded-full flex items-center justify-center bg-white/10 flex-shrink-0" aria-hidden="true">
                  <Play size={14} className="ml-0.5" />
                </span>
                Watch Demo
              </button>
            </div>
          </div>

          {/* Right: Illustration */}
          <div className="relative h-[420px] lg:h-[480px]">
            <HeroIllustration />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
