import React from 'react';

/**
 * Education-themed 3D SVG illustration:
 * Graduation cap atop glowing books, orbiting skill nodes,
 * glowing rings and connecting lines — all in the purple/violet palette.
 */
const HeroIllustration: React.FC = () => {
  return (
    <div className="relative w-full h-full flex items-center justify-center select-none">
      {/* Outer ambient glow */}
      <div
        className="absolute rounded-full animate-pulse-glow"
        style={{
          width: 420,
          height: 420,
          background: 'radial-gradient(circle, rgba(117,69,245,0.22) 0%, rgba(73,53,212,0.08) 55%, transparent 75%)',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
        }}
      />

      {/* SVG Illustration */}
      <svg
        viewBox="0 0 500 480"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full max-w-[500px] relative z-10 animate-float"
        aria-label="Education illustration with books, graduation cap and connected learning nodes"
        role="img"
      >
        <defs>
          <linearGradient id="bookGrad1" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#A78BFA" />
            <stop offset="100%" stopColor="#5B3BC0" />
          </linearGradient>
          <linearGradient id="bookGrad2" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#7545F5" />
            <stop offset="100%" stopColor="#3D2BA0" />
          </linearGradient>
          <linearGradient id="bookGrad3" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#C4B5FD" />
            <stop offset="100%" stopColor="#7545F5" />
          </linearGradient>
          <linearGradient id="capGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#1A1040" />
            <stop offset="100%" stopColor="#0D0820" />
          </linearGradient>
          <linearGradient id="glowRing" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#7545F5" stopOpacity="0" />
            <stop offset="50%" stopColor="#A78BFA" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#7545F5" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="platformGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#7545F5" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#4935D4" stopOpacity="0.1" />
          </linearGradient>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="6" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="softGlow">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>

        {/* ── Glowing platform ellipse ── */}
        <ellipse cx="250" cy="360" rx="165" ry="22" fill="url(#platformGrad)" />
        <ellipse cx="250" cy="360" rx="165" ry="22" fill="none" stroke="#7545F5" strokeWidth="1" opacity="0.4" />

        {/* ── Animated rings around the platform ── */}
        <ellipse cx="250" cy="360" rx="195" ry="30" fill="none" stroke="url(#glowRing)" strokeWidth="1.5" opacity="0.5" />

        {/* ── Books stack ── */}
        {/* Bottom book (widest) */}
        <g transform="translate(0, 10)">
          {/* Book 3 — bottom */}
          <rect x="130" y="310" width="240" height="45" rx="6" fill="url(#bookGrad2)" />
          <rect x="130" y="310" width="18" height="45" rx="4" fill="#3D2BA0" />
          <rect x="130" y="310" width="240" height="4" rx="2" fill="rgba(255,255,255,0.15)" />
          {/* Pages lines */}
          <line x1="148" y1="315" x2="148" y2="350" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
          {[0,1,2,3,4].map(i => (
            <line key={i} x1="160" y1={322 + i * 5} x2="355" y2={322 + i * 5} stroke="rgba(255,255,255,0.07)" strokeWidth="0.8" />
          ))}

          {/* Book 2 — middle */}
          <rect x="145" y="272" width="210" height="43" rx="6" fill="url(#bookGrad1)" />
          <rect x="145" y="272" width="18" height="43" rx="4" fill="#6B40C0" />
          <rect x="145" y="272" width="210" height="4" rx="2" fill="rgba(255,255,255,0.18)" />
          {[0,1,2,3].map(i => (
            <line key={i} x1="168" y1={280 + i * 7} x2="338" y2={280 + i * 7} stroke="rgba(255,255,255,0.07)" strokeWidth="0.8" />
          ))}

          {/* Book 1 — top */}
          <rect x="162" y="238" width="176" height="39" rx="6" fill="url(#bookGrad3)" />
          <rect x="162" y="238" width="16" height="39" rx="4" fill="#8B65D0" />
          <rect x="162" y="238" width="176" height="4" rx="2" fill="rgba(255,255,255,0.2)" />
          {[0,1,2].map(i => (
            <line key={i} x1="182" y1={247 + i * 7} x2="328" y2={247 + i * 7} stroke="rgba(255,255,255,0.08)" strokeWidth="0.8" />
          ))}
        </g>

        {/* ── Graduation Cap ── */}
        <g transform="translate(250, 230)">
          {/* Board (flat top) */}
          <ellipse cx="0" cy="-8" rx="88" ry="20" fill="url(#capGrad)" stroke="#A78BFA" strokeWidth="1.5" filter="url(#softGlow)" />
          {/* Top surface highlight */}
          <ellipse cx="0" cy="-8" rx="88" ry="20" fill="rgba(167,139,250,0.08)" />
          {/* Cap body */}
          <path d="M-56 -8 Q-56 28 0 36 Q56 28 56 -8" fill="url(#capGrad)" />
          <path d="M-56 -8 Q-56 28 0 36 Q56 28 56 -8" fill="none" stroke="#7545F5" strokeWidth="1" opacity="0.6" />
          {/* Button on top */}
          <circle cx="0" cy="-28" r="5" fill="#A78BFA" filter="url(#glow)" />
          {/* Tassel string */}
          <line x1="88" y1="-8" x2="100" y2="20" stroke="#A78BFA" strokeWidth="2" strokeLinecap="round" />
          <circle cx="100" cy="22" r="3" fill="#A78BFA" filter="url(#glow)" />
          {/* Tassel end */}
          {[-3, 0, 3].map((x, i) => (
            <line key={i} x1={97 + x} y1="25" x2={96 + x} y2="42" stroke="#A78BFA" strokeWidth="1.2" strokeLinecap="round" opacity="0.7" />
          ))}
          {/* Glow under cap */}
          <ellipse cx="0" cy="10" rx="70" ry="8" fill="rgba(117,69,245,0.3)" filter="url(#glow)" />
        </g>

        {/* ── Connecting node network ── */}
        {/* Connector lines */}
        <line x1="80" y1="180" x2="145" y2="260" stroke="rgba(167,139,250,0.3)" strokeWidth="1" strokeDasharray="5 4" />
        <line x1="400" y1="175" x2="355" y2="255" stroke="rgba(167,139,250,0.3)" strokeWidth="1" strokeDasharray="5 4" />
        <line x1="80" y1="180" x2="250" y2="130" stroke="rgba(117,69,245,0.25)" strokeWidth="1" strokeDasharray="5 4" />
        <line x1="400" y1="175" x2="250" y2="130" stroke="rgba(117,69,245,0.25)" strokeWidth="1" strokeDasharray="5 4" />
        <line x1="250" y1="130" x2="430" y2="80" stroke="rgba(167,139,250,0.2)" strokeWidth="1" strokeDasharray="5 4" />
        <line x1="250" y1="130" x2="60" y2="90" stroke="rgba(167,139,250,0.2)" strokeWidth="1" strokeDasharray="5 4" />

        {/* Node: Code icon */}
        <g transform="translate(55, 155)" filter="url(#softGlow)">
          <rect x="-28" y="-28" width="56" height="56" rx="14" fill="rgba(117,69,245,0.25)" stroke="rgba(117,69,245,0.5)" strokeWidth="1.5" />
          <text x="0" y="8" textAnchor="middle" fontSize="22" fill="#A78BFA">&lt;/&gt;</text>
        </g>

        {/* Node: Light bulb */}
        <g transform="translate(432, 155)" filter="url(#softGlow)">
          <rect x="-28" y="-28" width="56" height="56" rx="14" fill="rgba(167,139,250,0.2)" stroke="rgba(167,139,250,0.45)" strokeWidth="1.5" />
          <text x="0" y="8" textAnchor="middle" fontSize="22" fill="#C4B5FD">💡</text>
        </g>

        {/* Node: Chart */}
        <g transform="translate(432, 300)" filter="url(#softGlow)">
          <rect x="-28" y="-28" width="56" height="56" rx="14" fill="rgba(73,53,212,0.25)" stroke="rgba(73,53,212,0.5)" strokeWidth="1.5" />
          <text x="0" y="8" textAnchor="middle" fontSize="22" fill="#A78BFA">📊</text>
        </g>

        {/* Node: People */}
        <g transform="translate(55, 310)" filter="url(#softGlow)">
          <rect x="-28" y="-28" width="56" height="56" rx="14" fill="rgba(167,139,250,0.2)" stroke="rgba(167,139,250,0.45)" strokeWidth="1.5" />
          <text x="0" y="8" textAnchor="middle" fontSize="22" fill="#C4B5FD">👥</text>
        </g>

        {/* Center network hub */}
        <g transform="translate(250, 130)">
          <circle cx="0" cy="0" r="20" fill="rgba(117,69,245,0.2)" stroke="#7545F5" strokeWidth="1.5" />
          <circle cx="0" cy="0" r="10" fill="#7545F5" filter="url(#glow)" />
          {/* Pulse rings */}
          <circle cx="0" cy="0" r="20" fill="none" stroke="#7545F5" strokeWidth="1" opacity="0.5" className="animate-node-pulse" />
          <circle cx="0" cy="0" r="30" fill="none" stroke="#7545F5" strokeWidth="0.5" opacity="0.3" className="animate-node-pulse delay-300" />
        </g>

        {/* Small accent nodes */}
        {[
          { cx: 60, cy: 90, r: 6 },
          { cx: 430, cy: 80, r: 6 },
        ].map((n, i) => (
          <g key={i}>
            <circle cx={n.cx} cy={n.cy} r={n.r + 8} fill="rgba(117,69,245,0.15)" />
            <circle cx={n.cx} cy={n.cy} r={n.r} fill="#7545F5" filter="url(#softGlow)" />
          </g>
        ))}

        {/* Stars */}
        {[
          { x: 460, y: 50, s: 3 },
          { x: 30, y: 60, s: 2.5 },
          { x: 480, y: 230, s: 2 },
          { x: 20, y: 240, s: 2 },
          { x: 320, y: 50, s: 2 },
          { x: 165, y: 50, s: 1.5 },
        ].map((s, i) => (
          <circle key={i} cx={s.x} cy={s.y} r={s.s} fill="white" opacity="0.7" />
        ))}
      </svg>

      {/* Floating accent chips */}
      <div
        className="absolute top-8 left-6 glass rounded-xl px-3 py-2 flex items-center gap-2 animate-float-slow"
        style={{ animationDelay: '1s' }}
        aria-hidden="true"
      >
        <span className="text-lg">🎓</span>
        <div>
          <div className="text-xs font-semibold text-white">Skill Match</div>
          <div className="text-[10px] text-white/50">Found 24 peers</div>
        </div>
      </div>

      <div
        className="absolute bottom-14 right-4 glass rounded-xl px-3 py-2 flex items-center gap-2 animate-float-slow"
        style={{ animationDelay: '2.5s' }}
        aria-hidden="true"
      >
        <span className="text-lg">⚡</span>
        <div>
          <div className="text-xs font-semibold text-white">Live Session</div>
          <div className="text-[10px] text-white/50">React Basics</div>
        </div>
      </div>
    </div>
  );
};

export default HeroIllustration;
