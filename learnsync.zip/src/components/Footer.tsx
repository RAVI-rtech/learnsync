import React from 'react';
import { GitBranch, Globe, Share2, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  const year = new Date().getFullYear();

  const links = {
    platform: [
      { label: 'About', href: '#about' },
      { label: 'Features', href: '#features' },
      { label: 'Community', href: '#community' },
      { label: 'Skills', href: '#skills' },
    ],
    legal: [
      { label: 'Privacy Policy', href: '#privacy' },
      { label: 'Terms of Service', href: '#terms' },
      { label: 'Cookie Policy', href: '#cookies' },
    ],
    contact: [
      { label: 'Contact Us', href: 'mailto:hello@learnsync.io' },
      { label: 'Support', href: '#support' },
      { label: 'Feedback', href: '#feedback' },
    ],
  };

  const socials = [
    { Icon: GitBranch, label: 'GitHub', href: 'https://github.com' },
    { Icon: Globe, label: 'Twitter / X', href: 'https://twitter.com' },
    { Icon: Share2, label: 'LinkedIn', href: 'https://linkedin.com' },
    { Icon: Mail, label: 'Email', href: 'mailto:hello@learnsync.io' },
  ];

  return (
    <footer
      className="relative border-t border-white/[0.07]"
      style={{ background: 'linear-gradient(180deg, #080B2A 0%, #04061A 100%)' }}
      aria-label="Site footer"
    >
      {/* Top glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-px"
        style={{ background: 'linear-gradient(90deg, transparent, rgba(117,69,245,0.6), transparent)' }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">

          {/* Brand column */}
          <div className="lg:col-span-2">
            {/* Logo */}
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8">
                <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
                  <defs>
                    <linearGradient id="footerLogoGrad" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                      <stop offset="0%" stopColor="#A78BFA"/>
                      <stop offset="100%" stopColor="#7545F5"/>
                    </linearGradient>
                  </defs>
                  <path d="M4 6L16 2L28 6V16C28 23 22 28 16 30C10 28 4 23 4 16V6Z" fill="url(#footerLogoGrad)" opacity="0.15"/>
                  <path d="M4 6L16 2L28 6V16C28 23 22 28 16 30C10 28 4 23 4 16V6Z" stroke="url(#footerLogoGrad)" strokeWidth="1.5"/>
                  <path d="M10 16L14.5 20.5L22 11.5" stroke="url(#footerLogoGrad)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <span className="text-xl font-bold">
                <span className="text-white">Learn</span>
                <span className="text-gradient-purple">Sync</span>
              </span>
            </div>

            <p className="text-white/50 text-sm leading-relaxed mb-5 max-w-xs">
              A premium student network connecting learners across colleges to exchange skills,
              share knowledge and grow together.
            </p>

            {/* Socials */}
            <div className="flex items-center gap-3">
              {socials.map(({ Icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  target={href.startsWith('http') ? '_blank' : undefined}
                  rel={href.startsWith('http') ? 'noreferrer noopener' : undefined}
                  aria-label={label}
                  className="w-9 h-9 rounded-lg glass flex items-center justify-center text-white/50 hover:text-white hover:border-white/20 transition-all hover:scale-110"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Platform links */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Platform</h3>
            <ul className="flex flex-col gap-2.5">
              {links.platform.map(({ label, href }) => (
                <li key={label}>
                  <a
                    href={href}
                    className="text-sm text-white/50 hover:text-white transition-colors"
                    onClick={(e) => e.preventDefault()}
                  >
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal links */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Legal</h3>
            <ul className="flex flex-col gap-2.5">
              {links.legal.map(({ label, href }) => (
                <li key={label}>
                  <a
                    href={href}
                    className="text-sm text-white/50 hover:text-white transition-colors"
                    onClick={(e) => e.preventDefault()}
                  >
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact links */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Contact</h3>
            <ul className="flex flex-col gap-2.5">
              {links.contact.map(({ label, href }) => (
                <li key={label}>
                  <a
                    href={href}
                    className="text-sm text-white/50 hover:text-white transition-colors"
                  >
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/[0.07] pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-sm text-white/35">
            © {year} LearnSync. All rights reserved.
          </p>
          <p className="text-sm text-white/25">
            Built with ❤️ for students everywhere
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
