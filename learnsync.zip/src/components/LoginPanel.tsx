import React, { useState } from 'react';
import { X, Mail, Lock, Eye, EyeOff, ArrowRight } from 'lucide-react';

interface LoginPanelProps {
  onClose: () => void;
  onSwitchToRegister: () => void;
}

const GoogleIcon = () => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="20" height="20" aria-hidden="true">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
  </svg>
);

const LoginPanel: React.FC<LoginPanelProps> = ({ onClose, onSwitchToRegister }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Authentication to be implemented with Supabase in Phase 2
    alert('Authentication will be connected to Supabase in Phase 2.');
  };

  return (
    <div
      className="modal-backdrop"
      role="dialog"
      aria-modal="true"
      aria-labelledby="login-title"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="modal-content glass-strong rounded-2xl w-full max-w-sm mx-4 p-8 relative">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg glass hover:bg-white/10 transition-colors text-white/60 hover:text-white"
          aria-label="Close login panel"
        >
          <X size={18} />
        </button>

        {/* Header */}
        <div className="mb-7">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl" aria-hidden="true">👋</span>
            <h2 id="login-title" className="text-2xl font-bold text-white">Welcome Back!</h2>
          </div>
          <p className="text-sm text-white/50">Continue your LearnSync journey</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} noValidate>
          <div className="flex flex-col gap-4 mb-5">
            {/* Email */}
            <div>
              <label htmlFor="login-email" className="sr-only">Email address</label>
              <div className="relative">
                <Mail
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/35 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  id="login-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email Address"
                  className="input-glass"
                  autoComplete="email"
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label htmlFor="login-password" className="sr-only">Password</label>
              <div className="relative">
                <Lock
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/35 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  id="login-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  className="input-glass !pr-11"
                  autoComplete="current-password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/35 hover:text-white/70 transition-colors"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
          </div>

          {/* Remember me + Forgot */}
          <div className="flex items-center justify-between mb-6 text-sm">
            <label className="flex items-center gap-2 cursor-pointer select-none group">
              <div
                className={`w-4 h-4 rounded border flex items-center justify-center transition-all ${
                  rememberMe
                    ? 'bg-primary border-primary'
                    : 'border-white/25 group-hover:border-white/50'
                }`}
                style={{ background: rememberMe ? '#7545F5' : undefined, borderColor: rememberMe ? '#7545F5' : undefined }}
                role="checkbox"
                aria-checked={rememberMe}
                aria-label="Remember me"
                tabIndex={0}
                onClick={() => setRememberMe(!rememberMe)}
                onKeyDown={(e) => e.key === ' ' && setRememberMe(!rememberMe)}
              >
                {rememberMe && (
                  <svg viewBox="0 0 12 12" width="10" height="10" fill="none">
                    <path d="M2 6L5 9L10 3" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                )}
              </div>
              <span className="text-white/60">Remember me</span>
            </label>

            <button
              type="button"
              className="text-accent hover:text-white transition-colors text-sm font-medium"
              onClick={() => alert('Password reset will be implemented in Phase 2.')}
            >
              Forgot password?
            </button>
          </div>

          {/* Login button */}
          <button
            type="submit"
            className="btn-primary w-full justify-center py-3 text-base mb-4"
          >
            Login
            <ArrowRight size={18} aria-hidden="true" />
          </button>

          {/* Divider */}
          <div className="flex items-center gap-3 mb-4" aria-hidden="true">
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-xs text-white/35">or</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>

          {/* Google */}
          <button
            type="button"
            className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl bg-white text-gray-800 font-semibold text-sm hover:bg-gray-100 transition-all hover:shadow-lg active:scale-[0.98]"
            onClick={() => alert('Google OAuth will be implemented in Phase 2.')}
          >
            <GoogleIcon />
            Continue with Google
          </button>
        </form>

        {/* Switch to Register */}
        <p className="text-center text-sm text-white/45 mt-6">
          Don&apos;t have an account?{' '}
          <button
            onClick={onSwitchToRegister}
            className="text-accent hover:text-white font-semibold transition-colors"
          >
            Sign Up
          </button>
        </p>
      </div>
    </div>
  );
};

export default LoginPanel;
