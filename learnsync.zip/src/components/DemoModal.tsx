import React from 'react';
import { X, Play } from 'lucide-react';

interface DemoModalProps {
  onClose: () => void;
}

const DemoModal: React.FC<DemoModalProps> = ({ onClose }) => {
  return (
    <div
      className="modal-backdrop"
      role="dialog"
      aria-modal="true"
      aria-labelledby="demo-title"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="modal-content glass-strong rounded-2xl w-full max-w-2xl mx-4 overflow-hidden relative">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/[0.08]">
          <div>
            <h2 id="demo-title" className="text-xl font-bold text-white">LearnSync Demo</h2>
            <p className="text-sm text-white/50 mt-0.5">See how LearnSync connects students</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg glass hover:bg-white/10 transition-colors text-white/60 hover:text-white"
            aria-label="Close demo"
          >
            <X size={18} />
          </button>
        </div>

        {/* Video placeholder */}
        <div className="relative bg-navy-900 aspect-video flex items-center justify-center group cursor-pointer"
          style={{ background: 'linear-gradient(135deg, #0D1240 0%, #080B2A 100%)' }}
        >
          {/* Placeholder illustration */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="relative mb-6">
                <div className="w-24 h-24 rounded-full flex items-center justify-center mx-auto"
                  style={{ background: 'rgba(117,69,245,0.2)', border: '2px solid rgba(117,69,245,0.5)' }}>
                  <Play size={36} className="text-purple-400 ml-1" aria-hidden="true" />
                </div>
                {/* Ring pulse */}
                <div className="absolute inset-0 w-24 h-24 mx-auto rounded-full animate-ping"
                  style={{ background: 'rgba(117,69,245,0.15)' }} />
              </div>
              <p className="text-white/60 text-sm font-medium">Demo video coming soon</p>
              <p className="text-white/35 text-xs mt-1">Full platform walkthrough will be available at launch</p>
            </div>
          </div>

          {/* Decorative background */}
          <div className="absolute inset-0 grid-lines opacity-30" />
        </div>

        {/* Features teaser */}
        <div className="p-6">
          <p className="text-white/60 text-sm mb-4">What you'll see in the demo:</p>
          <div className="grid grid-cols-2 gap-3">
            {[
              { icon: '🔄', text: 'Skill exchange matching' },
              { icon: '👥', text: 'Student community hub' },
              { icon: '📈', text: 'Career growth tools' },
              { icon: '📚', text: 'Interactive learning sessions' },
            ].map((item) => (
              <div key={item.text} className="flex items-center gap-2 text-sm text-white/70">
                <span className="text-base" aria-hidden="true">{item.icon}</span>
                {item.text}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DemoModal;
