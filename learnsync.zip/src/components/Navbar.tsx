import React from 'react';
import { Search, LogIn, Menu, X } from 'lucide-react';

interface NavbarProps {
  onLoginClick: () => void;
  activeSection: string;
  onNavClick: (section: string) => void;
}

const NAV_ITEMS = ['Home', 'Explore', 'Skills', 'Community', 'About'];

const Navbar: React.FC<NavbarProps> = ({ onLoginClick, activeSection, onNavClick }) => {
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [searchValue, setSearchValue] = React.useState('');

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 glass border-b border-white/[0.06]" role="navigation" aria-label="Main navigation">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <div
            className="flex items-center gap-2.5 cursor-pointer flex-shrink-0"
            onClick={() => onNavClick('Home')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && onNavClick('Home')}
            aria-label="LearnSync Home"
          >
            {/* SVG Logo Mark */}
            <div className="relative w-8 h-8">
              <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
                <defs>
                  <linearGradient id="logoGrad" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stopColor="#A78BFA"/>
                    <stop offset="100%" stopColor="#7545F5"/>
                  </linearGradient>
                </defs>
                <path d="M4 6L16 2L28 6V16C28 23 22 28 16 30C10 28 4 23 4 16V6Z" fill="url(#logoGrad)" opacity="0.15"/>
                <path d="M4 6L16 2L28 6V16C28 23 22 28 16 30C10 28 4 23 4 16V6Z" stroke="url(#logoGrad)" strokeWidth="1.5"/>
                <path d="M10 16L14.5 20.5L22 11.5" stroke="url(#logoGrad)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="10" cy="10" r="2" fill="#A78BFA"/>
                <circle cx="22" cy="10" r="2" fill="#7545F5"/>
                <circle cx="16" cy="20" r="2" fill="#A78BFA"/>
              </svg>
            </div>
            <span className="text-xl font-bold tracking-tight">
              <span className="text-white">Learn</span>
              <span className="text-gradient-purple">Sync</span>
            </span>
          </div>

          {/* Desktop Nav Items */}
          <div className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map((item) => (
              <button
                key={item}
                onClick={() => onNavClick(item)}
                className={`nav-link px-4 py-2 rounded-lg transition-all duration-200 ${
                  activeSection === item
                    ? 'active'
                    : 'hover:text-white hover:bg-white/[0.06]'
                }`}
                aria-current={activeSection === item ? 'page' : undefined}
              >
                {item}
              </button>
            ))}
          </div>

          {/* Search + Login */}
          <div className="hidden md:flex items-center gap-3">
            {/* Search */}
            <div className="relative">
              <Search
                size={15}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                placeholder="Search skills, people..."
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                className="input-glass !pl-9 !py-2 w-52 !text-sm"
                aria-label="Search skills and people"
              />
            </div>

            {/* Login */}
            <button
              onClick={onLoginClick}
              className="btn-primary !py-2 !px-5 !text-sm"
              aria-label="Open login"
            >
              <LogIn size={15} aria-hidden="true" />
              Login
            </button>
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden p-2 rounded-lg glass text-white/80 hover:text-white transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="md:hidden py-4 border-t border-white/[0.06]">
            <div className="flex flex-col gap-1 mb-4">
              {NAV_ITEMS.map((item) => (
                <button
                  key={item}
                  onClick={() => { onNavClick(item); setMobileOpen(false); }}
                  className={`nav-link text-left px-4 py-3 rounded-lg ${
                    activeSection === item ? 'active' : 'hover:bg-white/[0.06]'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
            <div className="flex flex-col gap-3 px-1">
              <div className="relative">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" aria-hidden="true" />
                <input
                  type="search"
                  placeholder="Search skills, people..."
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  className="input-glass !pl-9 !py-2.5 w-full !text-sm"
                  aria-label="Search"
                />
              </div>
              <button onClick={() => { onLoginClick(); setMobileOpen(false); }} className="btn-primary w-full justify-center">
                <LogIn size={16} aria-hidden="true" />
                Login
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
