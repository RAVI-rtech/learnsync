import React from 'react';
import { ArrowRight, RefreshCw, Users, TrendingUp, BookOpen } from 'lucide-react';

const FEATURES = [
  {
    icon: RefreshCw,
    emoji: '🔄',
    title: 'Skill Exchange',
    description: 'Share your skills and learn from others in a collaborative peer-to-peer environment.',
    color: '#7545F5',
    glow: 'rgba(117,69,245,0.35)',
  },
  {
    icon: Users,
    emoji: '👥',
    title: 'Student Community',
    description: 'Connect with students across colleges and build your professional network.',
    color: '#4935D4',
    glow: 'rgba(73,53,212,0.35)',
  },
  {
    icon: TrendingUp,
    emoji: '📈',
    title: 'Career Growth',
    description: 'Build your profile and discover opportunities tailored to your goals.',
    color: '#7545F5',
    glow: 'rgba(117,69,245,0.35)',
  },
  {
    icon: BookOpen,
    emoji: '📚',
    title: 'Interactive Learning',
    description: 'Share resources, join live sessions and learn together in real time.',
    color: '#6B58E8',
    glow: 'rgba(107,88,232,0.35)',
  },
] as const;

interface FeatureCardsProps {
  onGetStarted: () => void;
}

const FeatureCards: React.FC<FeatureCardsProps> = ({ onGetStarted }) => {
  return (
    <section
      id="features"
      aria-label="Platform features"
      className="relative py-20 px-4 sm:px-6 lg:px-8"
      style={{ background: 'linear-gradient(180deg, #080B2A 0%, #0A0E35 50%, #080B2A 100%)' }}
    >
      {/* Section header */}
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 mb-4">
            <span className="text-xs font-semibold text-accent uppercase tracking-widest">Platform Features</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mb-4">
            Everything you need to{' '}
            <span className="text-gradient-purple">grow together</span>
          </h2>
          <p className="text-white/55 max-w-xl mx-auto text-base">
            LearnSync brings together the best tools for student collaboration, skill development and career growth.
          </p>
        </div>

        {/* Cards grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {FEATURES.map((feature) => {
            const Icon = feature.icon;
            return (
              <article
                key={feature.title}
                className="glass-card rounded-2xl p-6 flex flex-col gap-4 group cursor-pointer"
                onClick={onGetStarted}
                tabIndex={0}
                role="button"
                onKeyDown={(e) => e.key === 'Enter' && onGetStarted()}
                aria-label={`${feature.title}: ${feature.description}`}
              >
                {/* Icon */}
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 group-hover:scale-110"
                  style={{
                    background: `linear-gradient(135deg, ${feature.color}30 0%, ${feature.color}15 100%)`,
                    border: `1px solid ${feature.color}40`,
                    boxShadow: `0 0 20px ${feature.glow}`,
                  }}
                  aria-hidden="true"
                >
                  <Icon size={22} style={{ color: feature.color }} />
                </div>

                {/* Content */}
                <div className="flex-1">
                  <h3 className="text-base font-bold text-white mb-2 group-hover:text-accent transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-white/55 leading-relaxed">
                    {feature.description}
                  </p>
                </div>

                {/* Arrow */}
                <div className="flex items-center justify-end">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-300 group-hover:translate-x-1"
                    style={{
                      background: `${feature.color}20`,
                      border: `1px solid ${feature.color}30`,
                    }}
                    aria-hidden="true"
                  >
                    <ArrowRight size={15} style={{ color: feature.color }} />
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default FeatureCards;
