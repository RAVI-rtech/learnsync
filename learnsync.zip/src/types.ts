// Shared TypeScript types for LearnSync

export type NavItem = {
  label: string;
  href: string;
};

export type FeatureCard = {
  icon: string;
  title: string;
  description: string;
};

export type ModalType = 'login' | 'register' | 'demo' | null;
