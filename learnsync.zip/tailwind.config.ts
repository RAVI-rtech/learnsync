import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          950: '#04061A',
          900: '#080B2A',
          800: '#0D1240',
          700: '#121855',
        },
        primary: {
          DEFAULT: '#7545F5',
          light: '#9B72FF',
          dark: '#5A32D4',
        },
        secondary: {
          DEFAULT: '#4935D4',
          light: '#6B58E8',
        },
        accent: {
          DEFAULT: '#A78BFA',
          light: '#C4B5FD',
        },
        violet: {
          glow: '#7545F5',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Inter', 'system-ui', 'sans-serif'],
      },
      backgroundImage: {
        'hero-gradient': 'radial-gradient(ellipse 80% 60% at 50% -10%, #2D1B6B 0%, #080B2A 60%)',
        'card-gradient': 'linear-gradient(135deg, rgba(117,69,245,0.15) 0%, rgba(73,53,212,0.08) 100%)',
        'glow-primary': 'radial-gradient(circle at center, rgba(117,69,245,0.4) 0%, transparent 70%)',
        'glow-accent': 'radial-gradient(circle at center, rgba(167,139,250,0.3) 0%, transparent 70%)',
      },
      boxShadow: {
        'glow-sm': '0 0 20px rgba(117,69,245,0.3)',
        'glow-md': '0 0 40px rgba(117,69,245,0.4)',
        'glow-lg': '0 0 60px rgba(117,69,245,0.5)',
        'card': '0 4px 24px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.08)',
        'card-hover': '0 8px 40px rgba(117,69,245,0.3), inset 0 1px 0 rgba(255,255,255,0.12)',
      },
      backdropBlur: {
        xs: '2px',
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'float-slow': 'float 9s ease-in-out infinite',
        'pulse-glow': 'pulseGlow 3s ease-in-out infinite',
        'fade-in': 'fadeIn 0.6s ease-out forwards',
        'slide-up': 'slideUp 0.6s ease-out forwards',
        'orbit': 'orbit 20s linear infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-16px)' },
        },
        pulseGlow: {
          '0%, 100%': { opacity: '0.6', transform: 'scale(1)' },
          '50%': { opacity: '1', transform: 'scale(1.05)' },
        },
        fadeIn: {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        slideUp: {
          from: { opacity: '0', transform: 'translateY(24px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        orbit: {
          from: { transform: 'rotate(0deg) translateX(120px) rotate(0deg)' },
          to: { transform: 'rotate(360deg) translateX(120px) rotate(-360deg)' },
        },
      },
    },
  },
  plugins: [],
}

export default config
